﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MVCEFDemo.Models;
using MVCEFDemo.Services;

namespace MVCEFDemo.Controllers
{
    [Route("blogs")]
    public class BlogController : Controller
    {
        private IBlogService _blogService;

        public BlogController(IBlogService blogService)
        {
            _blogService = blogService;
        }
        
        [HttpGet("", Name = "ListBlog")]
        public IActionResult Index([FromServices]IBlogService svc)
        {
            var model = svc.GetBlogs();
            return View(model);
        }
        [HttpGet("new", Name ="AddBlog")]
        public IActionResult Create()
        {

            return View();
        }

        [ValidateAntiForgeryToken]
        [HttpPost("new", Name ="AddBlog")]
        public IActionResult Create(Blog model)
        {
            if (ModelState.IsValid)
            {
                model.AddedDate = DateTime.Now;
                this._blogService.AddBlogAsync(model);
                return RedirectToAction("Index");

            }
            else
            {
                ModelState.AddModelError("", "Invalid blog data!");
                return View();
            }

        }

        [HttpGet("edit/{id:int?}", Name ="EditBlog")]
        public async Task<IActionResult> Edit([FromRoute]int? id)
        {
            var model = await _blogService.GetBlogByIdAsync(id.Value);

            return View(model);
        }

        [HttpPost("edit/{id:int?}", Name ="EditBlog")]
        public async Task<IActionResult> Edit([FromRoute]int? id, [Bind("Id","Title","Content", "Email", "AddedDate")]Blog model)
        {
            if (ModelState.IsValid)
            {
                await this._blogService.UpdateBlogAsync(id.Value, model);

                return RedirectToAction("Index");
            }
            else
            {
                return View(model);
            }

        }
    }
}