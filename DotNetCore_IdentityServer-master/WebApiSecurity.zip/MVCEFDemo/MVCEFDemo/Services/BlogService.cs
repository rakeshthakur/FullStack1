﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MVCEFDemo.Models;

namespace MVCEFDemo.Services
{
    public class BlogService : IBlogService
    {
        public IEnumerable<Blog> GetBlogs()
        {
            using (BlogContext db = new BlogContext())
            {
                return db.Blogs.ToList();
            }
        }

        public async Task<Blog> UpdateBlogAsync(int id, Blog blog)
        {
            using (BlogContext db = new BlogContext())
            {
                if (id!= blog.Id)
                {
                    throw new ApplicationException("Not found!");
                }
                db.Update(blog);
                await db.SaveChangesAsync();
            }
            return blog;
        }

        async Task<Blog> IBlogService.AddBlogAsync(Blog blog)
        {
            using (BlogContext db = new BlogContext())
            {
                db.Blogs.Add(blog);
                await db.SaveChangesAsync();
                return blog;
            }
            
        }

        async Task<Blog> IBlogService.GetBlogByIdAsync(int id)
        {
            using (BlogContext db = new BlogContext())
            {
                var blog = await db.Blogs.FindAsync(id);
                return blog;
            }
        }
    }
}
