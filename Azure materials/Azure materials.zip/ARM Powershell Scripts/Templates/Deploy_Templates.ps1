﻿
Login-AzureRmAccount 

Set-AzureRmContext -SubscriptionName 'Developer Program Benefit'

New-AzureRmResourceGroup -Name 'DeliveryGroup' -Location 'SouthEast Asia'

New-AzureRmResourceGroupDeployment -Name 'ARMDeploymentDemo' `
          -ResourceGroupName 'DeliveryGroup' `
          -TemplateFile 'C:\Users\sonusathyadas\Desktop\VSArmDemo\VSArmDemo\WindowsVirtualMachine.json' `
          -TemplateParameterFile 'C:\Users\sonusathyadas\Desktop\VSArmDemo\VSArmDemo\WindowsVirtualMachine.parameters.json' `
          -Force -Verbose