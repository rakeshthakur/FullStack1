﻿#Login 
Login-AzureRmAccount

#Create Resource group
New-AzureRmResourceGroup -Name "TrainingGroup" -Location "Southeast Asia"

#Create a service plan
New-AzureRmAppServicePlan -Name "ByteStreamStandardPlan" `
                        -ResourceGroupName "TrainingGroup" `
                        -Location "Southeast Asia" `
                        -Tier Standard `
                        -WorkerSize Large `
                        -NumberofWorkers 3

#Create a web app
New-AzureRmWebApp -ResourceGroupName "TrainingGroup" `
                -Name "bytestreamtrainingapp" `
                -Location "Southeast Asia" `
                -AppServicePlan "ByteStreamStandardPlan" 

#Create Deplyment slots
$webapp=Get-AzureRmWebApp -ResourceGroupName "TrainingGroup" `
                -Name "bytestreamtrainingapp"

New-AzureRmWebAppSlot -ResourceGroupName "TrainingGroup" `
                -Name $webapp.Name `
                -Slot "TestingSlot" `
                -AppServicePlan "ByteStreamStandardPlan" 


#Scaling - Updating plan from Standard to Premium and change instance size and count
$appServicePlan=Get-AzureRmAppServicePlan -ResourceGroupName "TrainingGroup" `
                -Name "ByteStreamStandardPlan"

Set-AzureRmAppServicePlan -ResourceGroupName "TrainingGroup" `
                -Name $appServicePlan.Name `
                -Tier Premium `
                -WorkerSize Medium `
                -NumberofWorkers 2


#Remove a deployment slot
Remove-AzureRmWebAppSlot -ResourceGroupName "TrainingGroup" `
                -Name $webapp.Name `
                -Slot "TestingSlot" -Force -Confirm


#Remove web app
Remove-AzureRmWebApp -ResourceGroupName "TrainingGroup" `
                -Name $webapp.Name `
                -Force

#Remove app service plan                           
Remove-AzureRmAppServicePlan -ResourceGroupName "TrainingGroup" `
                -Name "ByteStreamStandardPlan" `
                -Force -Confirm