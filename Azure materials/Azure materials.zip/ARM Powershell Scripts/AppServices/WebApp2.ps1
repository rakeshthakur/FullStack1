﻿
#Login to Azure account
Login-AzureRmAccount

#Set active subscription
Set-AzureRmContext -Subscription "Visual Studio Ultimate with MSDN"

$ResourceGroupName="AppGroup"
$Location="Southeastasia"
$WebAppName="synsampleapp"
$AppServicePlanName="MyAppServicePlan"

#Create a new resource group
New-AzureRmResourceGroup -Name $ResourceGroupName -Location $Location

#Create an App Service Plan
$appPlan=New-AzureRmAppServicePlan -Name  $AppServicePlanName`
        -Tier Standard `
        -Location $Location `
        -ResourceGroupName $ResourceGroupName    
        
#Create a web app
New-AzureRmWebApp -Name $WebAppName `
        -ResourceGroupName $ResourceGroupName `
        -Location $Location `
        -AppServicePlan $AppServicePlanName        

#Scale web app
Set-AzureRMAppServicePlan -Name $AppServicePlanName  `
        -ResourceGroupName $ResourceGroupName `
        -NumberofWorkers 3
