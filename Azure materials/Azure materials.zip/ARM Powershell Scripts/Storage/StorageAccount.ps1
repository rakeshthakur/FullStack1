﻿
Login-AzureRmAccount

$resourceGroupName="TrainingGroup"
$location="Southeast Asia"
$storageAccoutName="trainingstorage123987";

#Create Resource group 
New-AzureRmResourceGroup -Name $resourceGroupName -Location $location

#Get the resoruce group if already exits
$resourceGroup=Get-AzureRmResourceGroup -Name $resourceGroupName -Location $location

#Check whether storage account name is available or not
if(Get-AzureRmStorageAccountNameAvailability -Name $storageAccoutName){

    New-AzureRmStorageAccount -ResourceGroupName $resourceGroupName `
                    -Name $storageAccoutName `
                    -SkuName Standard_LRS `
                    -Location $location `
                    -Kind Storage
}

#Create a blob container 
$storageAccountKeys=Get-AzureRmStorageAccountKey -ResourceGroupName $resourceGroupName `
                        -Name $storageAccoutName 
                       

$context=New-AzureStorageContext -StorageAccountName $storageAccoutName `
                        -StorageAccountKey $storageAccountKeys[0].Value

New-AzureStorageContainer -Name "images" `
                        -Context $context

#Remove the containers
Remove-AzureStorageContainer -Name "images" `
                        -Context $context

#Create a table 
New-AzureStorageTable -Name "datatable" `
                    -Context $context

#Remove the table
Remove-AzureStorageTable -Name "datatable" `
                    -Context $context

#remove storage account
Remove-AzureRmStorageAccount -ResourceGroupName $resourceGroupName `
                    -Name $storageAccoutName -Force -Confirm