﻿Function New-AzVirtualMachine(){
 [CmdletBinding()]
Param(

  [Parameter(Mandatory=$true,HelpMessage="Name of the Resource Group")] 
  [string]$ResourceGroupName ,  
  [Parameter(Mandatory=$true,HelpMessage="Name of the Virtual Machine")] 
  [string]$VmName,  
  [Parameter(Mandatory=$true,HelpMessage="Location of the VM")] 
  [string]$Location,  
  [Parameter(Mandatory=$true,HelpMessage="Virtual Network Name")] 
  [string]$VirtualNetName,  
  [Parameter(Mandatory=$true,HelpMessage="Subnet Information")] 
  [string]$SubnetName,  
  [Parameter(Mandatory=$true,HelpMessage="Network Security group Information")] 
  [string]$NetSecGroup,
  [Parameter(Mandatory=$true,HelpMessage="Name of the Availability Set")] 
  [string]$AvSetName

 )
    
     #if(Get-AzureRmResourceGroup -Name $ResourceGroupName -ErrorAction SilentlyContinue){

     if(Check-ResourceGroup -ResourceGroupName $ResourceGroupName){
      
           Write-Host "Checking Whether Resource Exist Or not "

           #if(Get-AzureRmVm -Name $VmName -ResourceGroupName $ResourceGroupName -ErrorAction Ignore){

           if(Check-AzVirtualMachine -ResourceGroupName $ResourceGroupName -VmName $VmName){
         
                Write-Host "VM with this name already Exists"
            }
            else{

               Try{
                $user = "swpnlgkwd"
                $pw = ConvertTo-SecureString "System123456" -AsPlainText -Force
                $cred = New-Object –TypeName System.Management.Automation.PSCredential –ArgumentList $user, $pw

                $vm= New-AzureRmVm `
                         -ResourceGroupName $ResourceGroupName `
                         -Name $VmName `
                        -Location $Location `
                        -VirtualNetworkName $VirtualNetName `
                        -SubnetName $SubnetName `
                        -SecurityGroupName $NetSecGroup `
                        -OpenPorts 80 `
                        -AvailabilitySetName $AvSetName `
                        -Credential $cred `
                        -AsJob
                }
                catch{

                 Write-Host "Something Went Wrong" $Error[0]
                }
             }
            }        
        
     
     else{
      Write-Host "Resource with this name doesnt exist"
     }
}

# Function will check for the existence of Virtual Machine
Function Check-AzVirtualMachine(){
  [CmdletBinding()]
 Param(
  [Parameter(Mandatory=$true,HelpMessage="Name of the Resource Group")] 
  [string]$ResourceGroupName ,  
  [Parameter(Mandatory=$true,HelpMessage="Name of the Virtual Machine")] 
  [string]$VmName
  )

   $vmExists=Get-AzureRmVm -Name $VmName `
    -ResourceGroupName $ResourceGroupName `
    -ErrorAction Ignore
    return $vmExists;
}

    <#
    #$cred=Get-Credential
    #Get-Help New-AzureRmVM -Examples
   $user = "swpnlgkwd"
   $pw = ConvertTo-SecureString "System123456" -AsPlainText -Force
   $cred = New-Object –TypeName System.Management.Automation.PSCredential –ArgumentList $user, $pw

    $vm= New-AzureRmVm `
        -ResourceGroupName $ResourceGroupName `
        -Name $VmName `
        -Location $Location `
        -VirtualNetworkName $VirtualNetName `
        -SubnetName $SubnetName `
        -SecurityGroupName $NetSecGroup `
        -OpenPorts 80 `
        -AvailabilitySetName $AvSetName `
        -Credential $cred `
        -AsJob

    return $vm
    }
    #>
