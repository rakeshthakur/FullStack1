﻿Login-AzureRmAccount

$dstkey = Get-AzureRmStorageAccountKey -StorageAccountName mslabstorage -ResourceGroupName MSLabGroup

$dstcontext = New-AzureStorageContext -StorageAccountName mslabstorage -StorageAccountKey $dstkey.Value[0]

$copyblob = Start-AzureStorageBlobCopy -AbsoluteUri 'https://md-hx50k5jw2wxp.blob.core.windows.net/gvxw0srvx502/abcd?sv=2017-04-17&sr=b&si=3335a843-6025-43e7-a3ef-a8a67c2cb523&sig=auh1lavRwy%2BjAOIneCiN%2FV%2F19IySBgxzVo3B%2BKxsGcQ%3D' `
        -DestContext $dstcontext `
        -DestContainer disks `
        -DestBlob mslabvm.vhd

$copyblob | Get-AzureStorageBlobCopyState –WaitForComplete