﻿ Function New-AzAvailabiltySet(){
  [CmdletBinding()]
 Param(
 
  [Parameter(Mandatory=$true,HelpMessage="Name of the Resource Group To Create")]
  [string]$ResourceGroupName ,
  [Parameter(Mandatory=$true,HelpMessage="Availability Set Name")]
  [string]$AvSetName,
   [Parameter(Mandatory=$true,HelpMessage="Location of Resource")]
  [string]$Location
 )
             
             
              #$avSet = Get-Help Get-AzureRmAvailabilitySet -Examples
              $currentAvSet= Get-AzureRmAvailabilitySet -ResourceGroupName $ResourceGroupName `
               -Name $AvSetName -ErrorAction SilentlyContinue
              if($currentAvSet -eq $null){       
               $avSet= New-AzureRmAvailabilitySet `
                 -ResourceGroupName $ResourceGroupName `
                 -Name $AvSetName `
                 -Location $Location `
                 -Sku aligned `
                 -PlatformFaultDomainCount 2 `
                 -PlatformUpdateDomainCount 2
               Write-Host  $AvSetName " Created Successfully"

                 }
                 else{
                  Write-Host  $currentAvSet.Name "  Availability Set already Exist : " 
                 }

                 #return $avSet

}