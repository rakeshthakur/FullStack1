﻿# Do Sysprep before this 

$vmName = "myVM"
$rgName = "MSDELGroup"
$location = "South India"
$imageName = "myImage"



Stop-AzureRmVM -ResourceGroupName $rgName -Name $vmName -Force

Set-AzureRmVm -ResourceGroupName $rgName -Name $vmName -Generalized

$vm = Get-AzureRmVM -Name $vmName -ResourceGroupName $rgName

$image = New-AzureRmImageConfig -Location $location -SourceVirtualMachineId $vm.ID

New-AzureRmImage -Image $image -ImageName $imageName -ResourceGroupName $rgName