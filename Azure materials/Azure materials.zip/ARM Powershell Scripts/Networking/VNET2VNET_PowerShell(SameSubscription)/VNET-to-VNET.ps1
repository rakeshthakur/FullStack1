﻿#Login to Azure Account 
Login-AzureRmAccount 

#Select default subscription 
Set-AzureRmContext -SubscriptionName "<your subscription>" 

#Create a new Resource group 
$resourceGroup="HybridResGroup" 
$location="Southeast Asia" 
New-AzureRmResourceGroup -Name $resourceGroup `
        -Location $location

#Create first VNET 
$vnet1Name="VNET1"
$vnet1AddressPrefix1="10.0.0.0/16"
$vnet1AddressPrefix2="10.1.0.0/16"
$vnet1Subnet1Name="Frontend"
$vnet1Subnet1AddressPrefix="10.0.0.0/24"
$vnet1GatewaySubnetName="GatewaySubnet"
$vnet1GatewaySubnetAddressPrefix="10.1.255.0/27"

$frontendSubnet=New-AzureRmVirtualNetworkSubnetConfig -Name $vnet1Subnet1Name `
        -AddressPrefix $vnet1Subnet1AddressPrefix
        
$vnet1GatewaySubnet= New-AzureRmVirtualNetworkSubnetConfig -Name $vnet1GatewaySubnetName `
        -AddressPrefix $vnet1GatewaySubnetAddressPrefix

$vnet1=New-AzureRmVirtualNetwork -Name $vnet1Name `
        -ResourceGroupName $resourceGroup `
        -Location $location `
        -AddressPrefix $vnet1AddressPrefix1, $vnet1AddressPrefix2 `
        -Subnet $frontendSubnet, $vnet1GatewaySubnet

#Create Second VNET 
$vnet2Name="VNET2"
$vnet2AddressPrefix1="10.11.0.0/16"
$vnet2AddressPrefix2="10.12.0.0/16"
$vnet2Subnet1Name="Production"
$vnet2Subnet1AddressPrefix="10.11.0.0/24"
$vnet2GatewaySubnetName="GatewaySubnet"
$vnet2GatewaySubnetAddressPrefix="10.12.255.0/27"


$productionSubnet=New-AzureRmVirtualNetworkSubnetConfig -Name $vnet2Subnet1Name `
        -AddressPrefix $vnet2Subnet1AddressPrefix
        
$vnet2GatewaySubnet= New-AzureRmVirtualNetworkSubnetConfig -Name $vnet2GatewaySubnetName `
        -AddressPrefix $vnet2GatewaySubnetAddressPrefix

$vnet2=New-AzureRmVirtualNetwork -Name $vnet2Name `
        -ResourceGroupName $resourceGroup `
        -Location $location `
        -AddressPrefix $vnet2AddressPrefix1, $vnet2AddressPrefix2 `
        -Subnet $productionSubnet, $vnet2GatewaySubnet


#Create Gateway for First VNET
$gw1publicIPName="Gateway1PIP"
$gw1IPConfigName="Gateway1IPConfig"
$gw1Name= $vnet1Name+"Gateway"

$gw1PIP=New-AzureRmPublicIpAddress -Name $gw1publicIPName `
        -ResourceGroupName $resourceGroup `
        -Location $location `
        -AllocationMethod Dynamic `
        -IpAddressVersion IPv4 `
        -Sku Basic

$vnet1=Get-AzureRmVirtualNetwork -Name $vnet1Name -ResourceGroupName $resourceGroup
$vnet1GatewaySubnet=Get-AzureRmVirtualNetworkSubnetConfig -Name $vnet1GatewaySubnetName -VirtualNetwork $vnet1
$gw1IPConfig=New-AzureRmVirtualNetworkGatewayIpConfig -Name $gw1IPConfigName `
        -Subnet $vnet1GatewaySubnet `
        -PublicIpAddress $gw1PIP

New-AzureRmVirtualNetworkGateway -Name $gw1Name `
        -ResourceGroupName $resourceGroup `
        -Location $location `
        -IpConfigurations $gw1IPConfig `
        -GatewayType Vpn `
        -VpnType RouteBased `
        -GatewaySku VpnGw1                  

#Create Gateway for Second VNET
$gw2publicIPName="Gateway2PIP"
$gw2IPConfigName="Gateway2IPConfig"
$gw2Name= $vnet2Name+"Gateway"

$gw2PIP=New-AzureRmPublicIpAddress -Name $gw2publicIPName `
        -ResourceGroupName $resourceGroup `
        -Location $location `
        -AllocationMethod Dynamic `
        -IpAddressVersion IPv4 `
        -Sku Basic

$vnet2=Get-AzureRmVirtualNetwork -Name $vnet2Name -ResourceGroupName $resourceGroup
$vnet2GatewaySubnet=Get-AzureRmVirtualNetworkSubnetConfig -Name $vnet2GatewaySubnetName -VirtualNetwork $vnet2
$gw1IPConfig=New-AzureRmVirtualNetworkGatewayIpConfig -Name $gw1IPConfigName `
        -Subnet $vnet2GatewaySubnet `
        -PublicIpAddress $gw1PIP

New-AzureRmVirtualNetworkGateway -Name $gw2Name `
        -ResourceGroupName $resourceGroup `
        -Location $location `
        -IpConfigurations $gw2IPConfig `
        -GatewayType Vpn `
        -VpnType RouteBased `
        -GatewaySku VpnGw1   

#Create Connections
$Connection1Name="VNET1toVNET2"
$Connection2Name="VNET2toVNET1"

$vnet1gw = Get-AzureRmVirtualNetworkGateway -Name $gw1Name -ResourceGroupName $resourceGroup
$vnet2gw = Get-AzureRmVirtualNetworkGateway -Name $gw2Name -ResourceGroupName $resourceGroup

New-AzureRmVirtualNetworkGatewayConnection -Name $Connection1Name `
        -ResourceGroupName $resourceGroup `
        -VirtualNetworkGateway1 $vnet1gw `
        -VirtualNetworkGateway2 $vnet2gw `
        -Location $location `
        -ConnectionType Vnet2Vnet `
        -SharedKey 'samplekey'

New-AzureRmVirtualNetworkGatewayConnection -Name $Connection2Name `
        -ResourceGroupName $resourceGroup `
        -VirtualNetworkGateway1 $vnet2gw `
        -VirtualNetworkGateway2 $vnet1gw `
        -Location $location `
        -ConnectionType Vnet2Vnet `
        -SharedKey 'samplekey'