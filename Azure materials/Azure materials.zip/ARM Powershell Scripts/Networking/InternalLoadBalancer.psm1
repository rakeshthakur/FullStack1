﻿
## Create a front-End IP Pool with the private address  for the address 
## This address is the incoming network traffic endpoint.

# Get the Virtual Network in get the subnet where you want to 
# To create a entire vm struc
Function New-AzInternalLoadBalancer(){
Param(
 
 [Parameter(Mandatory=$true,HelpMessage="Name of the Virtual Network")]        
 [string]$VirtualNetName,
[Parameter(Mandatory=$true,HelpMessage="Name of the Resource Group")]          
 [string]$ResourceGroupName,
[Parameter(Mandatory=$true,HelpMessage="FrontEnd IP Config Name")]          
[string]$LBInternaFrontIPConfigName, 
[Parameter(Mandatory=$true,HelpMessage="Private IP Address")]          
 [string]$PrivateIPAddress, 
   [Parameter(Mandatory=$true,HelpMessage="Back end address pool")]          
 [string]$BeadressPoolName,
 
   [Parameter(Mandatory=$true,HelpMessage="Health Probe to Create")]
          
 [string]$AppHealthProbe,
 [string]$AppInternalLBName,
 [string]$Location
)


 $lb= Check-AzInternalLoadBalancer -AppInternalLBName $AppInternalLBName `
  -ResourceGroupName $ResourceGroupName 

   if($lb -eq $null)
    {
        $virtualNetwork= Get-AzureRmVirtualNetwork `
        -Name $VirtualNetName `
        -ResourceGroupName $ResourceGroupName -ErrorAction SilentlyContinue
        Write-Host $virtualNetwork.Subnets[1].Id 

                if($virtualNetwork -ne $null){

                    $frontendIP = New-AzureRmLoadBalancerFrontendIpConfig `
                    -Name $LBInternaFrontIPConfigName `
                    -PrivateIpAddress $PrivateIPAddress `
                    -SubnetId $virtualNetwork.subnets[1].Id 

                    $beaddresspool= New-AzureRmLoadBalancerBackendAddressPoolConfig `
                    -Name $BeadressPoolName
        
                     $inboundNATRule1= New-AzureRmLoadBalancerInboundNatRuleConfig `
                    -Name "RDP1" `
                    -FrontendIpConfiguration $frontendIP `
                     -Protocol TCP `
                    -FrontendPort 3441 `
                    -BackendPort 3389

                    $inboundNATRule2= New-AzureRmLoadBalancerInboundNatRuleConfig `
                    -Name "RDP2" `
                    -FrontendIpConfiguration $frontendIP `
                    -Protocol TCP `
                    -FrontendPort 3442 `
                    -BackendPort 3389

                        
                    $healthProbe = New-AzureRmLoadBalancerProbeConfig `
                    -Name $AppHealthProbe `
                    -RequestPath "HealthProbe.aspx" `
                    -Protocol http `
                    -Port 80 `
                    -IntervalInSeconds 15 `
                    -ProbeCount 2

                    $lbrule = New-AzureRmLoadBalancerRuleConfig `
                    -Name "HTTPRule" `
                    -FrontendIpConfiguration $frontendIP `
                    -BackendAddressPool $beaddresspool `
                    -Probe $healthProbe `
                    -Protocol Tcp `
                    -FrontendPort 80 `
                    -BackendPort 80

                    $internalLB=New-AzureRmLoadBalancer `
                    -ResourceGroupName $ResourceGroupName `
                    -Name $AppInternalLBName `
                    -Location $Location `
                    -FrontendIpConfiguration $frontendIP `
                    -InboundNatRule $inboundNATRule1,$inboundNatRule2 `
                    -LoadBalancingRule $lbrule `
                    -BackendAddressPool $beAddressPool `
                    -Probe $healthProbe

                    }        
                else{
                        Write-Host "Virtual network not available"
                    }
        }
            
    else{
        Write-Host "Load Balancer Already Exists"
    }

        return $internalLB;
}

Function Check-AzInternalLoadBalancer(){
  Param(
 [string]$AppInternalLBName,
 [string]$ResourceGroupName
 )
   $lb= Get-AzureRmLoadBalancer -Name $AppInternalLBName -ResourceGroupName $ResourceGroupName `
      -ErrorAction SilentlyContinue

      return $lb

}

<#
Function Check-HealthProbeExists(){
 Param(
 [string]$ProbeName,
 [object]$LoadBalancer
 )
  $probe =Get-AzureRmLoadBalancerProbeConfig `
   -Name $ProbeName -LoadBalancer $LoadBalancer
   return $probe

}
#>