﻿#Login to Azure
Login-AzureRmAccount

#Create a new Resource group 
$resourceGroup="HybridResGroup" 
$location="Southeast Asia" 
$vnetName="VNET"
$vnetAddressPrefix1="192.168.0.0/16"
$vnetAddressPrefix2="10.254.0.0/16"
$vnetSubnet1Name="Frontend"
$vnetSubnet1AddressPrefix="192.168.1.0/24"
$vnetGatewaySubnetName="GatewaySubnet"
$vnetGatewaySubnetAddressPrefix="192.168.200.0/24"
$vpnClientAddressPool= "172.16.201.0/24"
$gatewayName="VNETGateway"
$gatewayPIPName="GatewayPIP"
$gatewayIPConfigName="GatewayIPConfig"

New-AzureRmResourceGroup -Name $resourceGroup `
        -Location $location


#Create VNET
$frontendSubnet=New-AzureRmVirtualNetworkSubnetConfig -Name $vnetSubnet1Name `
        -AddressPrefix $vnetSubnet1AddressPrefix
        
$vnetGatewaySubnet= New-AzureRmVirtualNetworkSubnetConfig -Name $vnetGatewaySubnetName `
        -AddressPrefix $vnetGatewaySubnetAddressPrefix

New-AzureRmVirtualNetwork -Name $vnetName `
        -ResourceGroupName $resourceGroup `
        -Location $location `
        -AddressPrefix $vnetAddressPrefix1, $vnetAddressPrefix2 `
        -Subnet $frontendSubnet, $vnetGatewaySubnet

#Get References
$vnet = Get-AzureRmVirtualNetwork -Name $vnetName -ResourceGroupName $resourceGroup
$gatewaySubnet = Get-AzureRmVirtualNetworkSubnetConfig -Name $vnetGatewaySubnetName -VirtualNetwork $vnet

#Create Gateway
$pip = New-AzureRmPublicIpAddress -Name $GatewayPIPName `
        -ResourceGroupName $resourceGroup `
        -Location $location `
        -AllocationMethod Dynamic

$ipconf = New-AzureRmVirtualNetworkGatewayIpConfig -Name $gatewayIPConfigName `
        -Subnet $gatewaySubnet `
        -PublicIpAddress $pip

New-AzureRmVirtualNetworkGateway -Name $gatewayName `
        -ResourceGroupName $resourceGroup `
        -Location $location `
        -IpConfigurations $ipconf `
        -GatewayType Vpn `
        -VpnType RouteBased `
        -EnableBgp $false `
        -GatewaySku VpnGw1 `
        -VpnClientProtocol "IKEv2"

#Add VPN Client Address Pool
$gateway = Get-AzureRmVirtualNetworkGateway -ResourceGroupName $resourceGroup -Name $gatewayName
Set-AzureRmVirtualNetworkGateway -VirtualNetworkGateway $gateway -VpnClientAddressPool $vpnClientAddressPool

#Create a self-signed certificate
$cert = New-SelfSignedCertificate -Type Custom `
        -KeySpec Signature `
        -Subject "CN=P2SRootCert" `
        -KeyExportPolicy Exportable `
        -HashAlgorithm sha256 `
        -KeyLength 2048 `
        -CertStoreLocation "Cert:\CurrentUser\My" `
        -KeyUsageProperty Sign `
        -KeyUsage CertSign

New-SelfSignedCertificate -Type Custom `
        -DnsName P2SChildCert `
        -KeySpec Signature `
        -Subject "CN=P2SChildCert" `
        -KeyExportPolicy Exportable `
        -HashAlgorithm sha256 `
        -KeyLength 2048 `
        -CertStoreLocation "Cert:\CurrentUser\My" `
        -Signer $cert `
        -TextExtension @("2.5.29.37={text}1.3.6.1.5.5.7.3.2")

#Export the Root certificate with out pvt key and export as Base 64 X509 -export as .cer file
#Export the Client Certificate with pvt key - Export as .pef file

$P2SRootCertName = "P2SAzureCert.cer"
$filePathForCert = "C:\Users\Sonu Sathyadas\Desktop\P2SAzureCert.cer"
$cert = new-object System.Security.Cryptography.X509Certificates.X509Certificate2($filePathForCert)
$CertBase64 = [system.convert]::ToBase64String($cert.RawData)
$p2srootcert = New-AzureRmVpnClientRootCertificate -Name $P2SRootCertName -PublicCertData $CertBase64
#Upload the Root certificate to azure
Add-AzureRmVpnClientRootCertificate -VpnClientRootCertificateName $P2SRootCertName `
        -VirtualNetworkGatewayname $gatewayName `
        -ResourceGroupName $resourceGroup `
        -PublicCertData $CertBase64