﻿# Create a Internet Facing Load balancer
<#
Azure load balancer maps the public IP address and port number of incoming traffic 
to the private IP address and port number of the virtual machine and vice versa for 
the response traffic from the virtual machine. Load balancing rules allow you to distribute 
specific types of traffic between multiple virtual machines or services
Create NAT rules for remote desktop access/SSH for virtual machines behind the load balancer

 Front End IP Configuration : Contains the Public IP Addresses for Incoming NW Traffic
 BackEnd AddressPool : Contains the NICS for the Virtual Machines that recieved NW traffic from load balancer
 Load Balancing Rules : Contains rules mapping a public port on the load blancer to back end address pool
 Inbound NAT Rules :- Contains rules mapping a public port on the load balancer to a port for a specific VM
 Probes - Contains Health Probes used to check availablity of VM instanaces in the back end address pool
#> 
Function New-AzLoadBalancer(){
 [CmdletBinding()]
Param(
   [Parameter(Mandatory=$true,HelpMessage="Name of the Resource Group To Create")]
          
    [string]$ResourceGroupName,
   [Parameter(Mandatory=$true,HelpMessage="Load Balancer Front End Name")]
          
    [string]$LBFrontEndName,
    [Parameter(Mandatory=$true,HelpMessage="Location ")]
   
    [string]$Location,
    [Parameter(Mandatory=$true,HelpMessage="Load Balancer Back End Name")]
   
    [string]$LBBackEnd,
    [Parameter(Mandatory=$true,HelpMessage="Load Balancer  Name")]
   
    [string]$LBName,
    [Parameter(Mandatory=$true,HelpMessage="Health Probe Name")]
   
    [string]$HealthProbeName,

    [Parameter(Mandatory=$true,HelpMessage="Load Balancer Rule Name")]
   
    [string]$LBRuleName
)

   
    # Create a Load Balancer and Configuration only if  The Load balancer not present
     # Get-Help Get-AzureRmLoadBalancer -Examples
      <# $lb= Get-AzureRmLoadBalancer -Name $LBName -ResourceGroupName $ResourceGroupName `
      -ErrorAction SilentlyContinue #>

      $lb =Check-AzLoadBalancer -LBName $LBName -ResourceGroupName $ResourceGroupName
      
     if($lb -eq $null){
     $PublicIP = New-AzureRmPublicIpAddress `
                -Name "PublicIp" `
                -ResourceGroupName $ResourceGroupName `
                -Location $Location `
                -AllocationMethod Static 

    #Create a Front End IP Pool that uses Public IP Resource
        $FrontEndIPConfig=New-AzureRmLoadBalancerFrontendIpConfig `
                          -Name $LBFrontEndName `
                          -PublicIpAddress $PublicIP

    # Create a Back End Address Pool
        $BackEndAddressPool=New-AzureRmLoadBalancerBackendAddressPoolConfig `
                           -Name $LBBackEnd

            # Create a Load Balancer with FronEndPool and BackEndPool
                $lb = New-AzureRmLoadBalancer `
                 -ResourceGroupName $ResourceGroupName `
                 -Name $LBName `
                 -Location $Location `
                 -FrontendIpConfiguration $FrontEndIPConfig `
                 -BackendAddressPool $BackEndAddressPool

            # Create a Health Probe   
                 Add-AzureRmLoadBalancerProbeConfig `
                 -Name $HealthProbeName `
                 -LoadBalancer $lb `
                 -Protocol tcp `
                 -Port 80 `
                 -IntervalInSeconds 15 `
                 -ProbeCount 2

            # Update the Load Balancer
                Set-AzureRmLoadBalancer -LoadBalancer $lb

                $probe = Get-AzureRmLoadBalancerProbeConfig `
                        -LoadBalancer $lb `
                        -Name $HealthProbeName

                Add-AzureRmLoadBalancerRuleConfig `
                -Name $LBRuleName `
                -LoadBalancer $lb `
                -FrontendIpConfiguration $lb.FrontendIpConfigurations[0] `
                -BackendAddressPool $lb.BackendAddressPools[0] `
                -Protocol Tcp `
                -FrontendPort 80 `
                -BackendPort 80 `
                -Probe $probe

            # Update the Balancer
            Set-AzureRmLoadBalancer -LoadBalancer $lb
           
           }
           else{

            Write-Host "Load Balancer already Exists"
           }
        return $lb

}

Function Check-AzLoadBalancer(){
  Param(
 [string]$LBName,
 [string]$ResourceGroupName
 )
   $lb= Get-AzureRmLoadBalancer -Name $LBName -ResourceGroupName $ResourceGroupName `
      -ErrorAction SilentlyContinue

      return $lb

}
