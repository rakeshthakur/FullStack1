﻿
 Function New-AzNetworkInterface(){
 Param(
 
  [Parameter(Mandatory=$true,HelpMessage="Name of the Resource Group To Create")]
  [string]$ResourceGroupName , 
  [Parameter(Mandatory=$true,HelpMessage="Name of the Network Interface Card")]
  [string]$NicName,
 [Parameter(Mandatory=$true,HelpMessage="Location")]
  [string]$Location,
  [Parameter(Mandatory=$true,HelpMessage="Load Balancer to Create")]
  [string]$LoadBalName,
  [Parameter(Mandatory=$true,HelpMessage="Subnet Name Information")]
  [string]$SubnetName,
  [Parameter(Mandatory=$true,HelpMessage="Name of Virtual Network")]
  [string]$VirtualNetworkName

 )
 
 
 # Get the The Virtual Network 

          <#  $virtualNetwork= Get-AzureRmVirtualNetwork `
            -Name $VirtualNetworkName `
            -ResourceGroupName $ResourceGroupName -ErrorAction SilentlyContinue #>

            # Check Virtual Network Function is Part of Virtual Network.psm1
            $virtualNetwork = Check-AzVirtualNetwork `
             -ResourceGroupName $ResourceGroupName `
             -Name $VirtualNetworkName

            if($virtualNetwork -ne $null){
            # Retirve the Subnet where you want to create the Network Interface
                    $subNet=Get-AzureRmVirtualNetworkSubnetConfig `
                    -Name $SubnetName `
                    -VirtualNetwork $virtualNetwork
        <#            $lb=Get-AzureRmLoadBalancer `
                    -Name $LoadBalName -ResourceGroupName $ResourceGroupName #>

                    # Check-LoadbalancerExists is Part of 
                    $lb=Check-AzLoadBalancer  `
                    -AppInternalLBName $LoadBalName `
                    -ResourceGroupName $ResourceGroupName

                    if($lb -ne $null){
 # To Create AzureRmNetworkInterface NicName , Subnet , $lb

                    New-AzureRmNetworkInterface `
                    -ResourceGroupName $ResourceGroupName `
                     -Name $NicName `
                        -Location $Location `
                        -Subnet $subNet `
                        -LoadBalancerBackendAddressPool $lb.BackendAddressPools[0]
                     }
                     else{
                        Write-Host "Load Balancer doesnt exist"
                     }
                   }
                   else{
                    Write-Host "Virtual Network is not available needed to Create Neteork interface"

                   }
            }