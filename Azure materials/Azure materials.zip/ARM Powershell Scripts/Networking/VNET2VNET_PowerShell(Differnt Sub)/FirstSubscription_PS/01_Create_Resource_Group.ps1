﻿#Login to Azure Account
Login-AzureRmAccount 

#Select default subscription 
Set-AzureRmContext -SubscriptionName "Developer Program Benefit"

#Create a new Resource group
$resourceGroupName="HybridCloudResourceGroup1"
$location="Southeast Asia"
New-AzureRmResourceGroup -Name $resourceGroupName `
                        -Location $location