﻿
#Create a Public IP for Virtual Network Gateway of FirstVNET
$resourceGroupName="HybridCloudResourceGroup1"
$VNETName="FirstVNET"
$VNETLocation="Southeast Asia"

$GatewayPublicIPName="FirstGatewayPublicIP"
$GatewayIPConfigName="FirstGatewayIPConfig"
$GatewayName="FirstVNETGateway"

$GatewayPublicIP = New-AzureRmPublicIpAddress -Name $GatewayPublicIPName `
                                    -ResourceGroupName $resourceGroupName `
                                    -Location $VNETLocation `
                                    -AllocationMethod Dynamic

$VNET = Get-AzureRmVirtualNetwork -Name $VNETName `
                        -ResourceGroupName $resourceGroupName

$GatewaySubnet = Get-AzureRmVirtualNetworkSubnetConfig -Name $GatewaySubnetName -VirtualNetwork $VNET

$GatewayIPConfig = New-AzureRmVirtualNetworkGatewayIpConfig -Name $GatewayIPConfigName -Subnet $GatewaySubnet -PublicIpAddress $GatewayPublicIP

New-AzureRmVirtualNetworkGateway -Name $GatewayName -ResourceGroupName $resourceGroupName `
                                -Location $VNETLocation -IpConfigurations $GatewayIPConfig -GatewayType Vpn `
                                -VpnType RouteBased -GatewaySku Standard