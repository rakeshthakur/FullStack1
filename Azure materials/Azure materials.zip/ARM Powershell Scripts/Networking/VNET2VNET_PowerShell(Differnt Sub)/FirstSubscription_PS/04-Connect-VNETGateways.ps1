﻿
#Create connection between two gateways

$resourceGroupName="HybridCloudResourceGroup1"
$GatewayName="FirstVNETGateway"
$VNETLocation="Southeast Asia"
$ConnectionName="FirstVNETtoSecondVNET"

#Get the gateways references
$VNETGateway = Get-AzureRmVirtualNetworkGateway -Name $GatewayName -ResourceGroupName $resourceGroupName

#Send the following values to the second subscription administrator to establish connection
$VNETGateway.Name
$VNETGateway.Id


#Connecting FirstVNET to SecondVNET
#Get the Gateway name and ID from second subscription administrator and store into the following variables
$RemoteGateway = New-Object Microsoft.Azure.Commands.Network.Models.PSVirtualNetworkGateway
$RemoteGateway.Name="xxxxxxxxxx"
$RemoteGateway.Id="xxxxxxxxxxxxxxxxxx"

New-AzureRmVirtualNetworkGatewayConnection -Name $ConnectionName `
                            -ResourceGroupName $resourceGroupName `
                            -VirtualNetworkGateway1 $VNETGateway `
                            -VirtualNetworkGateway2 $RemoteGateway `
                            -Location $VNETLocation `
                            -ConnectionType Vnet2Vnet `
                            -SharedKey 'sample1234'

