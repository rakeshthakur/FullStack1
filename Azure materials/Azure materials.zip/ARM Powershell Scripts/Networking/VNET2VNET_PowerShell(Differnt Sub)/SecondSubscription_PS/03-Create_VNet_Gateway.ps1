﻿
#Create a Public IP for Virtual Network Gateway of SecondVNET
$resourceGroupName="HybridCloudResourceGroup2"
$VNETName="SecondVNET"
$VNETLocation="Southeast Asia"
$GatewaySubnetName="GatewaySubnet"

$GatewayPublicIPName="SecondGatewayPublicIP"
$GatewayIPConfigName="SecondGatewayIPConfig"
$GatewayName="SecondVNETGateway"

$GatewayPublicIP = New-AzureRmPublicIpAddress -Name $GatewayPublicIPName `
                                    -ResourceGroupName $resourceGroupName `
                                    -Location $VNETLocation `
                                    -AllocationMethod Dynamic

$VNET = Get-AzureRmVirtualNetwork -Name $VNETName `
                        -ResourceGroupName $resourceGroupName

$GatewaySubnet = Get-AzureRmVirtualNetworkSubnetConfig -Name $GatewaySubnetName -VirtualNetwork $VNET


$GatewayIPConfig = New-AzureRmVirtualNetworkGatewayIpConfig -Name $GatewayIPConfigName -Subnet $GatewaySubnet -PublicIpAddress $GatewayPublicIP

New-AzureRmVirtualNetworkGateway -Name $GatewayName -ResourceGroupName $resourceGroupName `
                                -Location $VNETLocation -IpConfigurations $GatewayIPConfig -GatewayType Vpn `
                                -VpnType RouteBased -GatewaySku Standard
