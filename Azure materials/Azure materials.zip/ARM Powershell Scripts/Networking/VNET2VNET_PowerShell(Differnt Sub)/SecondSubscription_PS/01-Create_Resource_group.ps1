﻿#Login to Azure Account
Login-AzureRmAccount 

#Select default subscription 
Set-AzureRmContext -SubscriptionName "Visual Studio Ultimate with MSDN"

#Create a new Resource group
$resourceGroupName="HybridCloudResourceGroup2"
$location="Southeast Asia"
New-AzureRmResourceGroup -Name $resourceGroupName `
                        -Location $location