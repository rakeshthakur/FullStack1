﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace AzureSamples2.Models
{
    public class CatalogItem
    {
        [JsonProperty(PropertyName ="id")]          
        public Guid Id { get; set; }

        [JsonProperty(PropertyName ="name")]
        public string Name { get; set; }

        [JsonProperty(PropertyName ="price")]
        public double Price { get; set; }

        [JsonProperty(PropertyName ="quantity")]
        public int Quantity { get; set; }

        [JsonProperty(PropertyName ="createdDate")]
        public DateTime CreatedDate { get; set; }

    }
}
