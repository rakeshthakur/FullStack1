﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AzureSamples2.Models;
using AzureSamples2.Utils;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace AzureSamples2.Controllers
{
    [Route("api/[controller]")]
    public class AdminController : Controller
    {

        private readonly CosmosDbSettings cosmosDbSettings;

        public AdminController(IOptions<CosmosDbSettings> cosmosDbOptions)
        {
            this.cosmosDbSettings = cosmosDbOptions.Value;
        }

        [HttpPost("catalog/newitem")]
        public async Task<IActionResult> AddProduct([FromBody]CatalogItem catalogItem)
        {
            CosmosDBUtil util = new CosmosDBUtil(cosmosDbSettings);
            string documentId = await util.AddCatalogDocumentAsync(catalogItem);
            return Created($"api/admin/catalog/{documentId}", catalogItem);
        }

        [HttpGet("catalog")]
        public async Task<IEnumerable<CatalogItem>> GetCatalogItems()
        {
            CosmosDBUtil util = new CosmosDBUtil(cosmosDbSettings);
            var items = await util.GetCatalogItemsAsync();
            return items;
        }
    }
}