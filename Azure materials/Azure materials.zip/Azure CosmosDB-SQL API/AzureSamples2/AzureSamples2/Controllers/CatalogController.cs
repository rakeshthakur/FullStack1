﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AzureSamples2.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Options;
using AzureSamples2.Utils;
using Newtonsoft.Json;

namespace AzureSamples2.Controllers
{
    public class CatalogController : Controller
    {
        private readonly IDistributedCache cache;
        private readonly CosmosDbSettings cosmosDbSettings;

        public CatalogController(IDistributedCache cache, IOptions<CosmosDbSettings> cosmosDbOptions)
        {
            this.cache = cache;
            this.cosmosDbSettings = cosmosDbOptions.Value;
        }

        public async Task<IActionResult> Index()
        {
            IEnumerable<CatalogItem> items;
            string value = cache.GetString("items");
            if(value==null)
            {
                CosmosDBUtil util = new CosmosDBUtil(cosmosDbSettings);
                items = await util.GetCatalogItemsAsync();
                var itemsText = JsonConvert.SerializeObject(items);
                var options = new DistributedCacheEntryOptions();
                options.SetSlidingExpiration(TimeSpan.FromSeconds(120));
                cache.SetString("items", itemsText, options);
            }
            else
            {
                items= JsonConvert.DeserializeObject<IEnumerable<CatalogItem>>(value);                
            }
            return View(items);
        }
    }
}