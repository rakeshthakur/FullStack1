﻿using AzureSamples2.Models;
using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Microsoft.Azure.Documents.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AzureSamples2.Utils
{
    public class CosmosDBUtil
    {
        private readonly CosmosDbSettings cosmosDbSettings;
        private readonly DocumentClient client;

        public CosmosDBUtil(CosmosDbSettings settings)
        {
            this.cosmosDbSettings = settings;
            this.client = new DocumentClient(new Uri(cosmosDbSettings.EndPointUri), cosmosDbSettings.AccessKey);
        }

        public async Task<string> AddCatalogDocumentAsync(CatalogItem catalogItem)
        {
            try
            {
                Database database = new Database() { Id = cosmosDbSettings.DatabaseId };
                await client.CreateDatabaseIfNotExistsAsync(database);
                await client.CreateDocumentCollectionIfNotExistsAsync(UriFactory.CreateDatabaseUri(cosmosDbSettings.DatabaseId),
                    new DocumentCollection()
                    {
                        Id = cosmosDbSettings.CollectionId
                    }, new RequestOptions() { OfferThroughput = 400 });
                var document=await client.CreateDocumentAsync(UriFactory.CreateDocumentCollectionUri(cosmosDbSettings.DatabaseId, cosmosDbSettings.CollectionId), catalogItem);
                return document.Resource.Id;
            }catch(Exception ex)
            {
                throw new Exception("Error:" + ex.Message);
            }
        }
        
        public async Task<IEnumerable<CatalogItem>> GetCatalogItemsAsync()
        {
            try
            {
                IDocumentQuery<CatalogItem> query = client.CreateDocumentQuery<CatalogItem>(
                    UriFactory.CreateDocumentCollectionUri(cosmosDbSettings.DatabaseId, cosmosDbSettings.CollectionId),
                    new FeedOptions { MaxItemCount = -1 })                
                .AsDocumentQuery();

                List<CatalogItem> results = new List<CatalogItem>();
                while (query.HasMoreResults)
                {
                    results.AddRange(await query.ExecuteNextAsync<CatalogItem>());
                }
                return results;
            }
            catch (Exception ex)
            {
                throw new Exception("Error:" + ex.Message);
            }
        }
    }
}
