﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AzureSamples2
{
    public class CosmosDbSettings
    {
        public string EndPointUri { get; set; }

        public string AccessKey { get; set; }

        public string DatabaseId { get; set; }

        public string CollectionId { get; set; }
    }
}
